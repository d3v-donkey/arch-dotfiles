bin/bash

# Listes des programmes au démarrage
nm-applet &
gmrun &
blueman-applet &
volumeicon &
tint2 &
compton &
feh --bg-scale ~/wallpapers/fond-ecran-geek-14.jpg &
neofetch &
numlockx &
cups &
conky -c ~/conky/.conkyrc &

chmod +x ~/.tmux/tmuxperr.sh &
chmod +x ~/bin/* &
