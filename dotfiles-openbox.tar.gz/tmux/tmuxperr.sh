#!/bin/bash
#########################################################################
#########################################################################
## Dependence : 
##      terminology
##      tmux
##      wmctrl
#########################################################################       
## Usage :
## tmuxperr.sh <sessionnane> <application>
## to launch a shell just put "bash" on application argument
#########################################################################

## Variable definition :
WINDOW_NAME="Viperr TMUX Terminal"
TERM_EXIST=$(wmctrl -l|grep "$WINDOW_NAME")
#############################################
## Test syntax :
if [[ -z $1 ||-z $2 ]]; then
    echo "Please give a session name"
    echo -e "\nExample : ./terminux.sh Viperr application"
    exit 0
fi
#############################################
## start point : 
# test if a terminal exist with your given name :
if [ -z "$TERM_EXIST" ]
#NO 
then
        # test if TMUX session exist :
        if [[ -z $(tmux list-session) ]]
            then
                # test if application argument is bash ( no session exist )
                if [[ "$2" = "bash" ]] 
                    then
                        # yes : launch new Tmux session under your shell :
                        terminology -T "$WINDOW_NAME" -e "tmux -2 new-session -A -D -s $1" &
                    else
                        # no : launch your application under tmux :
                        terminology -T "$WINDOW_NAME"  -e "tmux -2 new-session -A -D -n $2 -s $1 $2 " &
                fi
            else
                # test if application argument is bash ( session exist )
                if [[ "$2" = "bash" ]]
                    then
                        # yes : test if window for your shell exist : 
                        if [[ -n $(tmux list-window -a -F '#{window_name}' | sed -n "/$LOGNAME/ s/\(.*\)@.*$/\1/p") ]]
                            then
                            #Yes : launch terminology and attach your shell windows ( if your have multi shell windows, this script attche only the first found )
                                terminology -T "$WINDOW_NAME" -e "tmux -2 attach -d -t $(tmux list-window  -a -F '#{window_name}|#{window_index}.#{pane_index}' | sed -n '/'$LOGNAME'/s/^.*|\(.*\)$/\1/p' | head -1) " &
                        
                            else
                                #No : Launch terminology with new shell window
                                terminology -T "$WINDOW_NAME" -e "tmux -2 attach-session \; new-window" &
                        fi
                    else
                        #No : test if window for your application exist : 
                        appli=$(tmux list-window -a -F '#{window_name}' | grep -i "$2"| cut -d " " -f 1)
                        if [[ -n  $appli ]]
                            then
                                #Yes : launch terminology and attach your application
                                terminology -T "$WINDOW_NAME" -e "tmux -2 attach -d -t $1:$appli" &

                            else
                                #No : Launch terminology with new window for your application
                                terminology -T "$WINDOW_NAME" -e "tmux -2 attach-session \; new-window $2" &
                        fi
                fi
        fi
#YES 
else
    # test if application argument is bash ( terminal open )
    if [[ "$2" = "bash" ]]
        then
            #yes : test if a shell windows exist : 
            if [[ "$LOGNAME" = $(tmux list-window -a -F '#{window_name}' | sed -n "/$LOGNAME/ s/\(.*\)@.*$/\1/p") ]]
                then
                    #yes : Select the First shell window
                    tmux -2 select-window -t "$1:$(tmux list-window -a -F '#{window_name}' | grep "$LOGNAME")"
                else
                    #No : Start new shell window
                    tmux -2 new-window -t "$1"
            fi

        else
            # NO : test if your application windows exist : 
            if [[ -n  $(tmux list-window -a -F '#{window_name}' | grep -i "$2") ]]
                then
                    #yes : Select your application window
                    tmux -2 select-window -t "$1:$(tmux list-window -a -F '#{window_name}' | grep -i "$2")"
                else
                    #no : Start new window for your application 
                    tmux -2 new-window -t "$1" -n "$2" "$2"
            fi
    fi
fi
#Focus on your terminal
wmctrl -a "$WINDOW_NAME"
